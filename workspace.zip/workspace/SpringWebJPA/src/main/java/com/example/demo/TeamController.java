package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TeamController {
	
	@Autowired
	TeamRepository teamRepository;
	
	@RequestMapping(value="/teamsInfo", method=RequestMethod.GET, produces=MediaType.APPLICATION_XML_VALUE,headers = "Accept=application/xml")
	public Iterable<Team> getTeams1(){
		return teamRepository.findAll();
	}
    @RequestMapping(value="/teams", method=RequestMethod.GET, produces=MediaType.APPLICATION_XML_VALUE,headers = "Accept=application/xml")
	public Teams getTeams(){
		List<Team> list = new ArrayList<>();
		Team team = new Team();
		team.setId(0l);
		team.setLocation("Harlem");
		team.setName("abc");
		list.add(team);
		 team = new Team();
		team.setId(1l);
		team.setLocation("Washington");
		team.setName("Generals");
		list.add(team);
		Teams teams = new Teams();
		teams.setTeams(list);
		return teams;
	}

     
}
