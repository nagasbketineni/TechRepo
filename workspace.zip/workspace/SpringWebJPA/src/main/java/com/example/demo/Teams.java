package com.example.demo;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement
public class Teams {
private List<Team> teams;

@XmlElement
public List<Team> getTeams() {
	return teams;
}

public void setTeams(List<Team> listofTeam) {
	this.teams = listofTeam;
}
}
