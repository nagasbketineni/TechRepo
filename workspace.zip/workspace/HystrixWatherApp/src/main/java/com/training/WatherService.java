package com.training;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

@Service
public class WatherService {

	@Autowired
	RestTemplate restTemplate;
	
	@HystrixCommand(fallbackMethod="unknown", commandProperties= {
			@HystrixProperty(name="execution.isolation.thread.timeoutInMilliseconds",value="10000")
	})
	public String getWeather() {
		return new RestTemplate().getForEntity("http://localhost:9000/weather", String.class).getBody();
	}
	public String unknown() {
		return "unknown";
	}
}
