package com.example.demo;

public class Account {
private int account,bal;
public Account() {
	
}
public Account(int account,int amt) {
	this.account=account;
	this.bal = amt;
}
public int getAccount() {
	return account;
}

public void setAccount(int account) {
	this.account = account;
}

public int getBal() {
	return bal;
}

public void setBal(int bal) {
	this.bal = bal;
}
}
