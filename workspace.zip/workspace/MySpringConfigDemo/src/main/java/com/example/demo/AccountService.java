package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@MyComponnet
public class AccountService {
	@Autowired
	AccountRepository accountRepository;
public void transfer(int acc1,int acc2, int amt) {
	Account acct1 = accountRepository.getAccount(acc1);
	Account acct2 = accountRepository.getAccount(acc2);
	acct1.setBal(acct1.getBal()-amt);
	acct2.setBal(acct2.getBal()+amt);

	System.out.println("transfered amount");
	System.out.println("account 1 ="+ acct1.getBal()+"");
	System.out.println("account 2 ="+ acct2.getBal()+"");

}
}
