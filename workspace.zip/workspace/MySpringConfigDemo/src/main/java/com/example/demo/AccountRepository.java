package com.example.demo;

import java.util.HashMap;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Component
public class AccountRepository {
	HashMap<Integer,Account> accounts = new HashMap<Integer,Account>();
	public AccountRepository() {
		accounts.put(1, new Account(1,100));
		accounts.put(2, new Account(2,100));

		accounts.put(3, new Account(3,100));


	}
public Account getAccount(int accountNum) {
	return accounts.get(accountNum);
}
}
