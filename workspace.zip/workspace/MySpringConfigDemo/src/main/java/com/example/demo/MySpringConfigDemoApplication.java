package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

//@SpringBootApplication
@Component
public class MySpringConfigDemoApplication {
	
	
	
@Autowired
	Environment ev;
	 @Value("${account1}")
	  private String account1;

	  @Value("${account2}")
	  private  String account2;
	public static void main(String[] args) {
		//ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		ApplicationContext context =  new AnnotationConfigApplicationContext(AccountConfig.class);
		AccountService acctservice = (AccountService)context.getBean("accountService");
		MySpringConfigDemoApplication mySpringConfigDemoApplication = (MySpringConfigDemoApplication)context.getBean(MySpringConfigDemoApplication.class);

		//acctservice.transfer(Integer.parseInt(mySpringConfigDemoApplication.account1), Integer.parseInt(mySpringConfigDemoApplication.account2), 300);
		
		//acctservice.transfer(Integer.parseInt(args[0]), Integer.parseInt(args[1]), 300);
		acctservice.transfer(Integer.parseInt(mySpringConfigDemoApplication.ev.getProperty("account1")), Integer.parseInt(mySpringConfigDemoApplication.ev.getProperty("account2")), 300);
	}
	
}
